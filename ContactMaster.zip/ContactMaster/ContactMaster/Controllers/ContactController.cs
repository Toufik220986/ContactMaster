﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ContactMaster.Controllers
{
    public class ContactController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            ContactMasterEntities entities = new ContactMasterEntities();
            List<CustomerDtl> customers = entities.CustomerDtls.Where(y=>y.Status==1).ToList();
            if (customers.Count == 0)
            {
                customers.Add(new CustomerDtl());
            }

            return View(customers);
        }
    }
}