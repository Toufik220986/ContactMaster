﻿using System;
using System.Web.Http;
using System.Linq;

namespace ContactMaster.Controllers
{
    public class CustomerAPIController : ApiController
    {
        [Route("api/CustomerAPI/InsertCustomer")]
        [HttpPost]
        public CustomerDtl InsertCustomer(CustomerDtl _customer)
        {
            using (ContactMasterEntities entities = new ContactMasterEntities())
            {
                _customer.Status = 1;
                entities.CustomerDtls.Add(_customer);
                entities.SaveChanges();
            }

            return _customer;
        }

        [Route("api/CustomerAPI/UpdateCustomer")]
        [HttpPost]
        public bool UpdateCustomer(CustomerDtl _customer)
        {
            using (ContactMasterEntities entities = new ContactMasterEntities())
            {
                CustomerDtl updatedCustomer = (from c in entities.CustomerDtls
                                            where c.ContactId == _customer.ContactId
                                            select c).FirstOrDefault();
                updatedCustomer.FirstName = _customer.FirstName;
                updatedCustomer.LastName = _customer.LastName;
                updatedCustomer.EmailId = _customer.EmailId;
                updatedCustomer.PhoneNumber = _customer.PhoneNumber;
                entities.SaveChanges();
            }

            return true;
        }

        [Route("api/CustomerAPI/DeleteCustomer")]
        [HttpPost]
        public void DeleteCustomer(CustomerDtl _customer)
        {
            using (ContactMasterEntities entities = new ContactMasterEntities())
            {
                CustomerDtl updatedCustomer = (from c in entities.CustomerDtls
                                               where c.ContactId == _customer.ContactId
                                               select c).FirstOrDefault();
                updatedCustomer.Status = 0;
                entities.SaveChanges();
            }
        }
    }
}
